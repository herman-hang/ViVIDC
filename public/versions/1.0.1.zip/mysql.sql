CREATE TABLE `vividc`.`test` ( `id` INT NOT NULL , `test1` VARCHAR(20) NOT NULL , `test2` TEXT NOT NULL , `test3` TINYINT(3) NOT NULL ) ENGINE = MyISAM;
ALTER TABLE `viv_admin` ADD `test` VARCHAR(50) NOT NULL AFTER `ban_time`
