<?php
return [
	//是否需要更新网站代码
	"is_code"	=> 	true,
	//是否需要更新数据库
	"is_sql"	=>	true,
];